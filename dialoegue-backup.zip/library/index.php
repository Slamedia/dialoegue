<?php
header('Location: ../index.php?aks=ditolak!');
exit;
